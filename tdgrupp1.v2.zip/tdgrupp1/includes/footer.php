<head>
    <link rel="stylesheet" href="css/footer.css" type="text/css">
</head> 
<footer id="mainfooter">
            <p>*********COPY RIGHT BY GUSTAF LINDBERG 2017*********</p>
        </footer><!-- /mainfooter -->
</body>
</html>

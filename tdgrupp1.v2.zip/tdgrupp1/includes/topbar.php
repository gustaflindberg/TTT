
<head>
	<title> TTT </title> 
	
	<!-- This is the topbar where the user can navigate between the pages --> 
	
	<meta charset="utf-8">
	<link rel="stylesheet" href="css/topbar.css" type="text/css">
</head>
<body>

<ul class="topnav" id="myTopnav">
  <li><a class="active" href="../index.php">Main</a></li>
  <li><a href="php/lab3info.php">Info</a></li>
  <li class="icon">
  </li>
</ul>
</body>
</html> 
<!DOCTYPE html> 
<html>
<title>TTT</title>
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="css/header.css" type="text/css">
    <title>PlottTest</title>
	<script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
	<script>
		function loadDoc() {
			var xhttp = new XMLHttpRequest();
		
			xhttp.onreadystatechange = function()
			{
				if (this.readyState == 4 && this.status == 200)
				{
					var data = JSON.parse(this.responseText);
					Plotly.newPlot('graf', data );
				}
			};
		
			xhttp.open("GET", "data.php", true);
			// xhttp.open("POST", "Oauth.php", true);
			xhttp.send();
		}
	</script>
</head>
<body>
    <div id="banner">
        <h1>Top trending tweets</h1>
        <header id="topbar">
            <?php include("includes/topbar.php"); ?>
        </header>
    </div>
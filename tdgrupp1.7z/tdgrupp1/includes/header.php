<!DOCTYPE html> 
<html>
<head>
<title>TTT</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="css/stylesheet.css" type="text/css">
</head>
<body>
    <div id="banner">
        <img src="header.jpg" id="headbann" alt="Banner" width="728" height="90">
       
    </div>
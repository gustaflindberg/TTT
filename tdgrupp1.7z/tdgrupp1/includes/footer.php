<footer id="mainfooter">
            <a href="https://twitter.com/intent/tweet?button_hashtag=TopTrendingTweets" class="twitter-hashtag-button" data-show-count="false">Tweet #TopTrendingTweets</a><script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script></p>
	
        </footer><!-- /mainfooter -->
</body>
</html>

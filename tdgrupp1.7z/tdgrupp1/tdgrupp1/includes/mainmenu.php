   <nav id="mainmenu">
                <ul>
                    <li><a href="index.php">Hem</a></li>
                    <li><a href="info.php">Info</a></li>
                    <li><a href="boka.php">Boka</a></li>
                </ul>
            </nav>
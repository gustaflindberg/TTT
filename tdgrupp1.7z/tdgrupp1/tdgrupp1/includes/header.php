<!DOCTYPE html> 
<html>
<head>
<title>TTT</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="css/header.css" type="text/css">
</head>
<body>
    <div id="banner">
        <h1>Top trending tweets</h1>
        <header id="topbar">
            <?php include("includes/topbar.php"); ?>
        </header>
    </div>
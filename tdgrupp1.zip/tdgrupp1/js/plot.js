		function plot(){
		document.getElementById("demo").innerHTML = 5 + 6;
		function loadDoc() {
			// https://www.w3schools.com/js/js_ajax_http_send.asp
			var xhttp = new XMLHttpRequest();
			
			// Denna funktion k�rs n�r ett svar kommit p� anropet fr�n servern.
			//		(N�r det skett en onreadystatechange-h�ndelse.)
			xhttp.onreadystatechange = function()
			{
				if (this.readyState == 4 && this.status == 200)
				{
					var data = JSON.parse(this.responseText);
					Plotly.newPlot('graf', data );
				}
			};
		
			// �ppna mot och anropa servern. Det g�r att anv�nda GET eller POST-anrop.
			xhttp.open("GET", "plotData.php", true);	//GET
			// xhttp.open("POST", "plotDataPHP.php", true);	//POST
			xhttp.send();
		}
		}
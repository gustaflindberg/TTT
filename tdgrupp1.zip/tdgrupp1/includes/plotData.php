	<?php
 echo "funkar de?";
	$data = [ [
		"x" => ["giraffes", "orangutans", "monkeys"],
		"y" => [20, 14, 13],
		"type" => "bar"  
	] ]; 
		 // $data = array();
		//	$data['x'] = {10,20,30,40,50};
		//	$data['y'] = {10,30,40,60,70};
	echo json_encode( $data);
	?>
	
			
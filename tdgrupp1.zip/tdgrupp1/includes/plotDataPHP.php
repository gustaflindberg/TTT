<?php

	// Ett PHP-objekt, med JSON-kodat data anpassat för Plotly.
	// Notera syntaxskillnaden mot Javascript i "plott_JS".
	$data = [ [
		"x" => ["giraffes", "orangutans", "monkeys"],
		"y" => [20, 14, 13],
		"type" => "bar"  
	] ]; 

	echo json_encode($data);

?>

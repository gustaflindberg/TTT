

<ul class="topnav" id="myTopnav">
  <li><a class="active" href="../index.php">Main</a></li>
  <li><a href="php/lab3info.php">Info</a></li>
  <li class="icon">
  </li>
</ul>

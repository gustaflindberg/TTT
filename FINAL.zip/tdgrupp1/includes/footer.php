<footer id="mainfooter">
            <a href="https://twitter.com/intent/tweet?button_hashtag=TopTrendingTweets" class="twitter-hashtag-button" data-show-count="false">Tweet #TopTrendingTweets</a><script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script></p>
	<input id="show" type="button" name="About Us" value="About Us" onclick="showDiv()" />
        </footer><!-- /mainfooter -->
		
	<div id="About_Us" style="display:none;">
	<h1> About us </h1>
	<p>This webpage is created to display different twitter trends worldwide. By us the drop down menu the user can select a country and view what is trending on twitter in that specific country.  </p>
	<p>If you have any suggestions for a country we can add to list or any other questions email us at: <a href="mailto: mahe1507@student.miun.se">Send Mail</a></p>
	
	</div>
</body>
</html>

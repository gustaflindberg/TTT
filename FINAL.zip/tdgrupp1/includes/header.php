<!DOCTYPE html> 
<html>
<head>
<title>TTT</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="css/stylesheet.css" type="text/css">
</head>
<body>
    <div id="pictures">
	<img class="arrow" img src="arrow.png" id="arrow" alt="arrow">
        <img class="banner" img src="bannerheader.jpg" id="banner" alt="Banner">
       
    </div>
	